package com.example.umstation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button_stationQR;  //스테이션 QR 인식버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_stationQR = findViewById(R.id.button_stationQR);

        //[Station QR]버튼 클릭 -> QR 인식 화면
        button_stationQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StationQRActivity.class);
                startActivity(intent);
            }
        });


    }
}